# My To-Do App

This is the README for Chapter 8, Section 8.4.2: Git Setup.