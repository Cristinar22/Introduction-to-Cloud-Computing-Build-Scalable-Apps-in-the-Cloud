#!/bin/bash
sudo apt update
sudo apt install nginx -y
echo 'Hello Cloud!' | sudo tee /var/www/html/index.html
sudo systemctl start nginx
