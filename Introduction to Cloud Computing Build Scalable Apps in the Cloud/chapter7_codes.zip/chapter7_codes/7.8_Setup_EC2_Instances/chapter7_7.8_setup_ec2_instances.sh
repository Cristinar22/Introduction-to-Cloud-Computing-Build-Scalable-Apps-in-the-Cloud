#!/bin/bash
# Chapter 7 - Step 1: Set Up EC2 Instances
# Launch two EC2 instances and install a web server

sudo apt update
sudo apt install nginx -y

# For Server 1
echo 'Hello from Server 1' | sudo tee /var/www/html/index.html

# On Server 2, change the message:
# echo 'Hello from Server 2' | sudo tee /var/www/html/index.html
