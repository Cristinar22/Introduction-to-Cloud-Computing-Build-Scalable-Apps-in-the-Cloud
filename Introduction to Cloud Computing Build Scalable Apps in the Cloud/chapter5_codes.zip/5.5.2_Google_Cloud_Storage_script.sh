#!/bin/bash
# Chapter 5.5.2: Google Cloud Storage Bucket Creation and File Upload

# Variables
BUCKET_NAME="my-first-bucket-jan2025"
REGION="US"
FILE_PATH="path/to/your-file.txt"

# Create Cloud Storage bucket
gsutil mb -l $REGION gs://$BUCKET_NAME/

# Upload file
gsutil cp $FILE_PATH gs://$BUCKET_NAME/

# Make object public (optional)
gsutil acl ch -u AllUsers:R gs://$BUCKET_NAME/$(basename $FILE_PATH)

# Generate signed URL (valid for 1 hour)
gsutil signurl -d 1h ~/.config/gcloud/your-key.json gs://$BUCKET_NAME/$(basename $FILE_PATH)
