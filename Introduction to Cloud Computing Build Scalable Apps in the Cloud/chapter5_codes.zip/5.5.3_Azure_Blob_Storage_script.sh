#!/bin/bash
# Chapter 5.5.3: Azure Blob Storage Container Creation and File Upload

# Variables
RESOURCE_GROUP="myResourceGroup"
STORAGE_ACCOUNT="mystorageacct$(date +%s)"
CONTAINER_NAME="chapter5-container"
FILE_PATH="path/to/your-file.txt"

# Create resource group
az group create --name $RESOURCE_GROUP --location eastus

# Create storage account
az storage account create --name $STORAGE_ACCOUNT --resource-group $RESOURCE_GROUP --location eastus --sku Standard_LRS

# Create Blob container
az storage container create --account-name $STORAGE_ACCOUNT --name $CONTAINER_NAME --public-access off

# Upload file
az storage blob upload --account-name $STORAGE_ACCOUNT --container-name $CONTAINER_NAME --name $(basename $FILE_PATH) --file $FILE_PATH

# Generate SAS token (valid for 1 hour)
az storage blob generate-sas --account-name $STORAGE_ACCOUNT --container-name $CONTAINER_NAME --name $(basename $FILE_PATH) --permissions r --expiry $(date -u -d "1 hour" '+%Y-%m-%dT%H:%MZ') --output tsv
