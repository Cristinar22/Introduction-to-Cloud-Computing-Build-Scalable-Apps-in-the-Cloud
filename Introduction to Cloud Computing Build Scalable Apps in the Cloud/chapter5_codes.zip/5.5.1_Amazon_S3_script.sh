#!/bin/bash
# Chapter 5.5.1: Amazon S3 Bucket Creation and File Upload

# Variables
BUCKET_NAME="my-first-bucket-jan2025"
REGION="us-east-1"
FILE_PATH="path/to/your-file.txt"

# Create S3 bucket
aws s3 mb s3://$BUCKET_NAME --region $REGION

# Upload file
aws s3 cp $FILE_PATH s3://$BUCKET_NAME/

# Make object public (optional)
aws s3api put-object-acl --bucket $BUCKET_NAME --key $(basename $FILE_PATH) --acl public-read

# Generate pre-signed URL (valid for 1 hour)
aws s3 presign s3://$BUCKET_NAME/$(basename $FILE_PATH) --expires-in 3600
