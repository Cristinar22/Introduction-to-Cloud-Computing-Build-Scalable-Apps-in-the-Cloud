# Chapter 6.6.3: Google Cloud SQL with Python

import mysql.connector

connection = mysql.connector.connect(
    host='YOUR_INSTANCE_IP',
    user='root',
    password='YOUR_PASSWORD',
    database='YOUR_DATABASE'
)

cursor = connection.cursor()
cursor.execute("CREATE TABLE books (title VARCHAR(100));")
cursor.execute("INSERT INTO books (title) VALUES ('Cloud Computing for All');")
cursor.execute("SELECT * FROM books;")
print(cursor.fetchall())
connection.close()
