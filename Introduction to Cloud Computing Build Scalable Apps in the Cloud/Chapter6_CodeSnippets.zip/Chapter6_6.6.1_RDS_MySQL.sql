-- Chapter 6.6.1: Setting Up Amazon RDS (MySQL) and Connecting

CREATE TABLE contacts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(50),
  email VARCHAR(100)
);

INSERT INTO contacts (name, email) VALUES ('Ada', 'ada@example.com');

SELECT * FROM contacts;
