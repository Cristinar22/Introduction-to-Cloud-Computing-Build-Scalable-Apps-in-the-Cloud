-- Chapter 6.7: Hands-On: Build a Simple Contact List in the Cloud

CREATE TABLE contacts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(50),
  phone VARCHAR(20),
  email VARCHAR(100)
);

INSERT INTO contacts (name, phone, email) VALUES ('Ngozi', '08012345678', 'ngozi@example.com');

SELECT * FROM contacts WHERE name = 'Ngozi';

UPDATE contacts SET phone = '08099998888' WHERE name = 'Ngozi';

DELETE FROM contacts WHERE name = 'Ngozi';
