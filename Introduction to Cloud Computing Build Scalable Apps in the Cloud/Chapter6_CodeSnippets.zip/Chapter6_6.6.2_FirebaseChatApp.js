// Chapter 6.6.2: Firebase Firestore Chat App Example

// Add Firebase SDK to your website (instructions in Firebase console)
const db = firebase.firestore();

db.collection("messages").add({
  name: "Chidi",
  text: "I love the cloud!",
  timestamp: Date.now()
})
.then((docRef) => {
  console.log("Message added: ", docRef.id);
});
